package temaPOO;

public class Test {

	public static void main(String[] args) {
		Application MyApp = Application.getInstance();
		
		
	}

}
