package temaPOO;

public interface IDepartment {
	double getTotalSalaryBudget( );
}
